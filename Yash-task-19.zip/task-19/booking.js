
let selectedItems = [];
let cart = [];

let cartDiv = document.querySelector("#cart");
let total = document.querySelector("#total");

let addButtons = document.querySelectorAll(".add");
let skipButtons = document.querySelectorAll(".skip");

addButtons.forEach(function(button) {

    button.addEventListener("click", function() {

        let name = button.dataset.name;
        let price = Number(button.dataset.price);

        selectedItems.push({
            name: name,
            price: price
        });

        alert(name + " selected");

    });

});

skipButtons.forEach(function(button) {

    button.addEventListener("click", function() {

        let service = button.parentElement;
        service.remove();

    });

});

document.querySelector("#addCart").addEventListener("click", function() {

    if (selectedItems.length === 0) {
        alert("Please select a service first");
        return;
    }

    selectedItems.forEach(function(item) {
        cart.push(item);
    });

    selectedItems = [];

    updateCart();

});

function updateCart() {

    cartDiv.innerHTML = "";

    let sum = 0;

    if (cart.length === 0) {
        cartDiv.innerHTML = "<p>No items added yet.</p>";
    }

    cart.forEach(function(item) {

        cartDiv.innerHTML += `
            <div class="cart-item">
                ${item.name} - ₹${item.price}
            </div>
        `;

        sum += item.price;

    });

    total.textContent = sum;

}

document.querySelector("#bookNow").addEventListener("click", function() {

    if (cart.length === 0) {
        alert("Your cart is empty");
        return;
    }

    document.querySelector(".booking").scrollIntoView({
        behavior: "smooth"
    });

});

document.querySelector("#confirm").addEventListener("click", function() {

    let name = document.querySelector("#fullname").value;
    let email = document.querySelector("#email").value;
    let password = document.querySelector("#password").value;

    if (name === "" || email === "" || password === "") {
        alert("Please fill all the fields");
        return;
    }

    if (cart.length === 0) {
        alert("Please add services to your cart");
        return;
    }

    alert("Booking confirmed! Thank you " + name);

    cart = [];
    selectedItems = [];

    updateCart();

    document.querySelector("#fullname").value = "";
    document.querySelector("#email").value = "";
    document.querySelector("#password").value = "";

});
